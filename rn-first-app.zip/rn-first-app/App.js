import React from "react";
import HomeNavigator from "./navigation/HomeNavigator";
import { createStore, combineReducers , applyMiddleware } from "redux";
import propertiesReducer from "./store/reducers/properties";
import { Provider } from "react-redux";
import ReduxThunk from 'redux-thunk';

export default function App() {
  const rootReducers = combineReducers({
    property: propertiesReducer,
  });
  const store = createStore(rootReducers , applyMiddleware(ReduxThunk));

  return (
    <Provider store={store}>
      <HomeNavigator />
    </Provider>
  );
}
