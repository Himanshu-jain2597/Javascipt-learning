

const propertiesReducer = (state =[] , action) => {

    return state;

}

export default propertiesReducer;