import React , {useState , useEffect} from "react";
import TagInput from 'react-native-tags-input';

import axios from "axios";
import {View , TextInput, StyleSheet, Button, FlatList ,  Text, TouchableOpacity} from "react-native";


const SearchInput = (props) => {
  console.log(props)
  const preference = props.route.params.preference;
  const [searchLocation,setSearchLocation] = useState({tags:{tag:'',tagsArray:[]}});
  const [showErrorMessage,setErrorMessage] = useState(false)
  const [nearLocality , setNearLocality] = useState([]);

  /** 
   * 
   */
  useEffect(()=> {

    fetchLocality();

  },[])

   /**
   * Fetch user from API. almost all the data does not have user key , bio  key , location key
   */
    const fetchLocality = async () => {
      try {
        const response = await axios.get(`https://www.99acres.com/api-aggregator/localities?city=7&resCom=${preference}&preference=S&platform=MSITE`);
        setNearLocality((prevState) => [...prevState, ...response.data]);
      } catch (e) {
        alert(e.message);
      }
    };

  if(searchLocation&&showErrorMessage) {
    setErrorMessage(false);
  }

  const onSearchLocation = () => {
    if(!searchLocation) {
        setErrorMessage(true);
        return;
    }
  }
 
    return (
        <View>
        <TagInput 
        tags = {searchLocation}
        // updateState = {()=> setSearchLocation(searchLocation)}
        />
        {showErrorMessage&&<Text style = {style.Error} >No Matching Found! please type a valid City or Locality</Text>}
        {nearLocality  && <FlatList keyExtractor={(item)=>item.NAME} data = {nearLocality} renderItem={({item})=> (
          <TouchableOpacity
          // onPress={()=> setSearchLocation((prevState)=>[...prevState, item.NAME])} 
          style= {style.popular}
          >
            <Text>{item.NAME}</Text>
            </TouchableOpacity>
        )}/>}
        <Button onPress = {onSearchLocation}  title = "search" />
      </View>
    )
}

const style =  StyleSheet.create({
  TextInput: {
    padding:15
  },
  Error: {
    color:'red'
  },
  popular: {
    padding:10,
    margin:2,
    backgroundColor:'rgba(0,0,0,0)',
    color:'black',
    borderColor:'silver',
    borderWidth:1,
    borderRadius:5
  }
});


export default SearchInput;