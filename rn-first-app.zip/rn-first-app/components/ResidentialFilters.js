import React from "react";

import { View, Text, StyleSheet, TouchableOpacity } from "react-native";

/**
 * Component to filter data on the residental properties
 * @param {*} props
 * @returns
 */
const ResidentalFilters = (props) => {
  return (
    <View>
      <TouchableOpacity onPress={() => props.navigation.navigate("Location", {
         
              preference:"R"
          
      })}>
        <View style = {styles.InputWrapper}>
          <Text>Where?</Text>
        </View>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  InputWrapper: {
      padding:10,
      width:'100%',
      borderBottomColor:'black',
      borderBottomWidth:1

  },
});

export default ResidentalFilters;
