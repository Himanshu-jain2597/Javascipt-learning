import React from "react";

import { View, Text , TouchableOpacity , StyleSheet} from "react-native";

/**
 * Component to filter data on the commerical properties
 * @param {*} props
 * @returns
 */
const CommericalFilters = (props) => {
  const propertyType = props.route.name;
  return (
    <View>
      <TouchableOpacity onPress={() => props.navigation.navigate("Location" , {
          preference : "C"
      })}>
        <View style={styles.InputWrapper}>
          <Text>Where?</Text>
        </View>
      </TouchableOpacity>
    </View>
  );
};
const styles = StyleSheet.create({
    InputWrapper: {
        padding:10,
        width:'100%',
        borderBottomColor:'black',
        borderBottomWidth:1
  
    },
  });
  

export default CommericalFilters;
