import React from "react";

import { View, Text, ImageBackground, StyleSheet, TouchableOpacity } from "react-native";


/**
 * Component render when we open a app
 * Landing Page
 * @param {*} props
 */
const HomeScreen = (props) => {
  return (
      <View >
        <View style={styles.InputWrapper}>
        <ImageBackground style = {styles.backGroundImage} source={require("../assets/images.jpg")}>
          <TouchableOpacity style={styles.TextWrapper} onPress={() => {
              props.navigation.navigate("Search");
            }}>
              <View style = {styles.button}>
                <Text style = {styles.buttonText}>
                Search Cities , Localities, projects , etc.
                </Text>
              </View>
          </TouchableOpacity>
        </ImageBackground>
        </View>
      </View>
  
  );
};

const styles = StyleSheet.create({
  InputWrapper: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent:"center",
    height:300
  },
  TextWrapper: {
    marginTop:200
  },
  TextInput: {
    padding: 20,
  },
  backGroundImage: {
      width:'100%',
      height:'100%',
      flex:1
  },
  button: {
    backgroundColor:"silver",
    padding:25
  },
  buttonText: {
    color:'black'
  }
});

export default HomeScreen;
