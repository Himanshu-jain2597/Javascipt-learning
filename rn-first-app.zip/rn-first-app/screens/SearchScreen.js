import React, { useState } from "react";

import SearchNavigator from "../navigation/SearchTopNavigator";

/**
 * Search Component
 */
const SearchScreen = (props) => {
  return (
    <SearchNavigator />
  );
};

export default SearchScreen;
