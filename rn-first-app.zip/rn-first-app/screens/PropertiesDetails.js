import React from "react";

import { View, Text } from "react-native";

const PropertiesDetails = (props) => {
  return (
    <View>
      <Text>Properties Details</Text>
    </View>
  );
};

export default PropertiesDetails;
