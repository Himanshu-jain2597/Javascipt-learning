import React , {useState} from "react";

import { View, Text, Switch , StyleSheet } from "react-native";


/** Filter Component To filter data based on various parameters */
const FilterScreen = () => {
    const [hideAlreadySeen ,  setHideAlreadySeen] = useState(false);
    const [verifiedProperties, setVerifiedProperties] = useState(false);

    return (
        <View style = {styles.homeScreen}>
            <View style={styles.toggleSwitch}>
                <Text>Hide Already Seen</Text>
                <Switch 
                value = {hideAlreadySeen}
                onValueChange={(value) => setHideAlreadySeen(value)}
                />
            </View>
            <View>
                <Text>Verified Properties</Text>
                <Switch 
                value = {verifiedProperties}
                onValueChange={(value) => setVerifiedProperties(value)}
                />
            </View>
            
        </View>
    )
}

const styles = StyleSheet.create({
    homeScreen: {
        flex:1,
        alignItems:'center',
    } , 
    toggleSwitch: {
        flexDirection:'row',
        justifyContent:'space-around',
        alignItems:'center'
    }
})


export default FilterScreen;
