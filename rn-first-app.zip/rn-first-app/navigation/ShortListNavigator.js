import React from "react";
import { View , Text  } from "react-native";

const ShortListNavigator = () => {

    return (
        <View><Text>ShortList</Text></View>
    )

}


export default ShortListNavigator;

