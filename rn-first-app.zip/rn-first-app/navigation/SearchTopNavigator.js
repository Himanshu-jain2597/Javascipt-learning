import React from "react";
import {StyleSheet, View } from "react-native";

import { createMaterialTopTabNavigator } from "@react-navigation/material-top-tabs";
import { NavigationContainer } from '@react-navigation/native';

import CommericalFilters from "../components/CommericalFilters";
import ResidentalFilters from "../components/ResidentialFilters";

const Tab = createMaterialTopTabNavigator();

const SearchNavigator = () => {
  return (
    <Tab.Navigator>
      <Tab.Screen   name="Residential" component={ResidentalFilters} />
      <Tab.Screen   name="Commercial" component={CommericalFilters} />
    </Tab.Navigator>
  );
};


export default SearchNavigator;