import React from "react";
import { createStackNavigator } from "@react-navigation/stack";
import { NavigationContainer } from "@react-navigation/native";
import HomeScreen from "../screens/HomeScreen";
import SearchScreen from "../screens/SearchScreen";
import PropertiesDetails from "../screens/PropertiesDetails";
import BottomTabNavigator from "./BottomNavigator";
import SearchInput from "../components/SearchInput";
const Stack = createStackNavigator();

const HomeNavigator = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="Search" component={SearchScreen} />
        <Stack.Screen name="Properties" component={PropertiesDetails} />
        <Stack.Screen name = "Location" component = {SearchInput} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default HomeNavigator;
